<script lang="ts">
  import { onMount } from 'svelte'
  import { createEventHandler, resolveElement } from './lib/utils'

  const eh = createEventHandler()
  let button: HTMLButtonElement | null = null
  onMount(() => {
    button = resolveElement('installPartTwoBtnId') as HTMLButtonElement
    button?.click()
    console.log(typeof eh.setup)
  })
</script>

<h3>Prisma Installation Part Two</h3>
<pre>
We assume that you finished the below tasks - Ctrl + double-click on .env file to
open it beside this Extension and enter a valid connection string and save the file
- Ctrl + double-click on /prisma/schema.prisma to open it beside the Extension and
prepare the schema models/tables Use model abilities for setting defaults, generating
Ids,... Save the model. By selecting the continue button the extension will issue
the final commands for installing Prisma ORM; otherwise you can enter the following
commands yourself BDNAME="MyDBNAME" # your database name DBOWNER='JohnDoe' # the name
of the database dropdb --if-exists -U "$DBOWNER" "$DBNAME" || true # or using this
command sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DBNAME;" createdb "$DBNAME"
-U "$DBOWNER" "GRANT ALL ON SCHEMA public TO $DBOWNER; GRANT CONNECT ON DATABASE $DBNAME
TO $DBOWNER;" sudo -u postgres psql -d "$DBNAME" -c "GRANT ALL PRIVILEGES ON SCHEMA
public TO $DBOWNER; ALTER SCHEMA public OWNER TO $DBOWNER; ALTER DATABASE dbtest OWNER
TO $DBOWNER;" sudo -u postgres psql -d "$DBNAME" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA
public GRANT ALL ON TABLES TO $DBOWNER; ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT ALL ON SEQUENCES TO $DBOWNER;" pnpx prisma migrate dev --name init # create
first migration (when ready)" pnpx prisma generate
</pre>
<button
  id="installPartTwoBtnId"
  style="margin-left:4rem;width:8.4rem;margin-top:1.7rem;">Continue</button
><button id="cancelPartTwoBtnId">Cancel</button>

<style lang="scss">
  pre {
    font-size: 14px;
    color: navy;
  }
</style>
