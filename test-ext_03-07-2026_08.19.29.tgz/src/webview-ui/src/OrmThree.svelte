<script lang="ts">
</script>

<div class="main">
  <p>App.page Svelte Page</p>
</div>

<style lang="scss">
  .main {
    margin: 3rem 0 0 1rem;
    border: 1px solid gray;
    border-radius: 10px;
  }
</style>
