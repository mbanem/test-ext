<script lang="ts">
  import { onMount } from 'svelte'
  import { type Theme, getInitialTheme } from '$lib/utils/toggle-theme'
  import { vscode } from '$lib/utils/event-handler.browser'

  import type { DbParams } from '../../extension.js'
  function postMessage(command: string, payload: string) {
    vscode.postMessage({ command, payload })
  }

  let db: DbParams = $state({
    name: 'dbrony',
    owner: 'rony',
    password: 'rony',
    host: 'localhost',
    port: 5432,
  })
  // let name = $state('dbrony')
  // let owner = $state('rony')
  // let password = $state('rony')
  // let host = $state('localhost')
  // let port = $state('5432')

  function installORMPartOne() {
    if (db.name && db.owner && db.password) {
      const db_: DbParams = {
        name: db.name,
        owner: db.owner,
        password: db.password,
        host: db.host ?? 'localhost',
        port: db.port ?? '5432',
      }
      postMessage('installPrismaPartOne', JSON.stringify(db_))
    }
  }

  // -------- toggle theme begin ---------
  let currentTheme: Theme = $state('light') // Svelte 5 runes syntax
  let mounted = $state(false)

  // Apply theme to document
  export function applyTheme() {
    document.documentElement.classList.add(currentTheme)
  }
  // Toggle theme
  export function toggleTheme() {
    document.documentElement.classList.remove(currentTheme)
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark'
    localStorage.setItem('theme', currentTheme)
    applyTheme()
  }
  // TODO Listen for system theme changes -- does not work
  $effect(() => {
    if (!mounted) return
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    const handleChange = (e: MediaQueryListEvent) => {
      // Only auto-change if user hasn't manually selected a theme
      if (!localStorage.getItem('theme')) {
        currentTheme = e.matches ? 'dark' : 'light'
        applyTheme()
      }
    }

    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  })
  function getIcon() {
    return currentTheme === 'dark' ? '☀️' : '🌙'
  }
  // Initialize on client
  onMount(() => {
    currentTheme = getInitialTheme()
    applyTheme()
    toggleTheme()
    mounted = true
  })
  // -------- toggle theme end ---------
</script>

<div class="theme-container">
  <p onclick={() => toggleTheme()} class="theme-icon" aria-hidden={true}>
    {getIcon()}
  </p>
  <div class="container">
    <pre id="installPartOneId">
      <h3>Prisma Installation Part One</h3>
The Extension 'Create CRUD Form Support' found that Prisma ORM is not installed in
the project; it can help with installing it. In the first part of the installation
it will add all the necessary packages and instantiate Prisma in this project by
installing a very basic schema in /prisma/schema.prisma file at the project's root.
  <div class="dbname-block">
    <label for="dbNameId">
      Database Name
      <br /><input
            bind:value={db.name}
            type="text"
            placeholder="avoid dashes in db-name"
          />
    </label>
    <label for="dbOwnerId">
      Database Owner
      <br /><input bind:value={db.owner} type="text" />
    </label>
    <label for="dbOwnerPasswordId">
      Owner's Password
      <br /><input bind:value={db.password} type="password" />
    </label>
    <label for="dbHostId">
      Host Name
      <br /><input bind:value={db.host} type="string" />
    </label>
    <label for="dbPortId">
      Communication Port
      <br /><input bind:value={db.port} type="number" />
    </label>
  </div>

By specifying database name, database owner name and owner's password the Extension will
set the database connection string in the .env file and install with no interaptions.
It will open schema.prisma and .env contents in separate windows and a continue button, 
waiting for you to 
  -  Specify your Prisma models/tables replacing the current schema.prisma content
  -  Specify the connection string in the opened .env file if not set by the Extension
When you are done select the continue button to finish the installation.
If you prefer to close the Extension, in order to finish the above tasks, you could
restart the Extension after that and it will display the commands that you should
enter yourself or to select the continue button to allow the Extension to finish the 
installation.

  <button onclick={installORMPartOne} style="margin-left:4rem;"
        >Install Prisma ORM</button
      ><button id="cancelPartOneBtnId">Cancel</button>
</pre>
  </div>
</div>

<style lang="scss">
  .container {
    margin: 2rem 0 0 5rem;
  }
  pre {
    grid-column: 1 / span 2;
    text-align: justify;
    line-height: 1rem;
  }

  // input[type='text'] {
  //   width: 18rem;
  //   height: 20px;
  //   padding: 6px 0 8px 1rem;
  //   outline: none;
  //   font-size: 16px;
  //   border: 1px solid gray;
  //   border-radius: 4px;
  //   outline: 1px solid transparent;
  //   margin-top: 8px;
  //   margin-bottom: 10px;
  // }

  // input[type='text']:focus {
  //   outline: 1px solid gray;
  // }

  // button {
  //   display: inline-block;
  //   margin: 1rem 1rem 1rem 0;
  //   /* background-color: navy;
  //   color: yellow;
  //   border: 1px solid gray;
  //   border-radius: 5px;*/
  //   font-size: 12px;
  //   cursor: pointer;
  //   padding: 3px 1rem;
  //   user-select: none;
  // }

  /* .hidden {
    display: none;
  } */
  .dbname-block {
    @include container($head: 'Database Parameters', $head-color: navy);
    display: grid;
    grid-template-columns: repeat(3, 12rem);
    column-gap: 0.2rem;
    margin: 0;
    padding: 1rem;

    label {
      width: 10rem;
      padding: 0;
      margin: 0 1rem 6px 0;
      color: var(--candidate-color);
    }

    input {
      width: 11rem;
      margin: 0;
      padding: 3px 0 3px 0.5rem !important;
      border: 1px solid lightgray;
      border-radius: 3px;

      &:focus {
        outline: 1px solid skyblue;
      }
    }
  }
  .theme-container {
    height: 98vh;
    width: 98vw;
    // background-color: var(--bg);
    color: var(--text);
    margin: 0;
    padding: 0;
    transition:
      background 0.4s ease,
      color 0.4s ease;
  }
  .theme-icon {
    position: absolute;
    top: 4rem;
    left: 41rem;
  }
</style>
